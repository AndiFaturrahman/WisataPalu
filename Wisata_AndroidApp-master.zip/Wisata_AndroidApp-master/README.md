# Wisata - Your Travelling Partner in Palu
Dibuat untuk memenuhi tugas UTS Pemrograman Mobile

### Dibuat oleh - Kelompok 8
1. Lukman Hakim_F55122038
2. Ifal Fahri A_F55122061
3. Vhio Tirta Anggun Azizah_F55122066
4. Munirah Abdilah_F55122068
